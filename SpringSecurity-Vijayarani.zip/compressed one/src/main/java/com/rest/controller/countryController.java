package com.rest.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.validation.*;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

import com.rest.model.country;

@RestController
public class countryController {

	Map<String,country> object=new HashMap<String,country>();
	
	@GetMapping("/country")
	public country getCountry()
	{
		country obj=new country();
		obj.setCode("UK");
		obj.setName("Russia");
		
		object.put(obj.getCode(), obj);
		
		return obj;
	}
	
	@GetMapping("/countries")
	public Map<String,country> getAllCountry()
	{
		return object;
	}
	
	@GetMapping("/countries/{code}")
	public country getOneCountry(@PathVariable String code)
	{	
		country obj=new country();
		
		for (Map.Entry<String,country> entry : object.entrySet()) 
		{
			System.out.println(entry.getValue().getCode());
			
			if(entry.getValue().getCode().equals(code))
			{
				obj=entry.getValue();
			}
			
		}
		
		
		return obj;
	}
	
	@PostMapping("/countries")
	public country createCountry(@RequestBody @Valid country obj)
	{
		/*ValidatorFactory factory =Validation.buildDefaultValidatorFactory();
		 Validator validator = factory.getValidator();
		 System.out.println("Validator: "+validator);
		  
		 Set<ConstraintViolation<country>> violations = validator.validate(obj);
		 
		  List<String> err = new ArrayList<String>();
		 
		 for (ConstraintViolation<country> v:violations){
	 err.add(v.getMessage()); }
		 
		 if(violations.size()>0){
		  throw new ResponseStatusException(HttpStatus.BAD_REQUEST,err.toString()); }*/
		
		
		if(object.containsKey(obj.getCode()))
		{
			obj.setName("Country Already Exists");
		}
		else
		{
			object.put(obj.getCode(), obj);	
		}
		
		return obj;
	}
	
	@PutMapping("/countries")
	public country updateCountry(@RequestBody country obj)
	{
		if(object.containsKey(obj.getCode()))
		{
			object.replace(obj.getCode(), obj);
		}
		else
		{
			obj.setName("Country not available");
		}
		
		return obj;
		}
	
	@DeleteMapping("/countries/{code}")
	public country deleteCountry(@PathVariable String code)
	{
		country obj=object.get(code);
		
		object.remove(code);
		return obj;
	}


}
	
	
	
	

